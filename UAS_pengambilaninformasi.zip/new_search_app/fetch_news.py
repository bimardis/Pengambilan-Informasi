import requests

API_KEY = "a693363c236b40ce9f005ae0e75f68c1"
BASE_URL = "https://newsapi.org/v2/everything"

def fetch_news(query, language="id", from_date=None):
    params = {
        "q": query,
        "language": language,
        "apiKey": API_KEY
    }
    if from_date:
        params["from"] = from_date  # Filter berdasarkan tanggal
    response = requests.get(BASE_URL, params=params)
    if response.status_code == 200:
        return response.json().get("articles", [])
    return []
