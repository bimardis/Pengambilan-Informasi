from flask import Flask, request, render_template
from fetch_news import fetch_news

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('search.html')

@app.route('/search', methods=['POST'])
def search():
    query = request.form.get('query')
    articles = fetch_news(query)
    return render_template('index.html', query=query, results=articles)

if __name__ == '__main__':
    app.run(debug=True)
